<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php
// index.php
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Estacionamento - Início</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h1>Estacionamento</h1>
        <p>Escolha uma opção:</p>
        <div class="nav">
            <a href="entrada.php">Entrada</a>
            <a href="saida.php">Saída</a>
            <a href="ativos.php">Ativos</a>
        </div>
    </div>
</div>
</body>
</html>
