<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
require 'config.php';
require 'funcoes.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Entrada de veículo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="entrada.php" class="active">Entrada</a>
        <a href="saida.php">Saída</a>
        <a href="ativos.php">Ativos</a>
    </div>

    <div class="card">
        <h1>Registrar entrada</h1>
        <form action="entrada_salvar.php" method="post" enctype="multipart/form-data">
            <label for="foto_placa">Foto da placa</label>
            <input type="file" name="foto_placa" id="foto_placa" accept="image/*" capture="environment">
            <label for="tipo_veiculo">Tipo de veículo *</label>
<select name="tipo_veiculo" id="tipo_veiculo" required>
    <option value="CARRO">Carro</option>
    <option value="ONIBUS">Ônibus</option>
</select>

<label for="cliente_tipo">Tipo de cliente *</label>
<select name="cliente_tipo" id="cliente_tipo" required>
    <option value="NORMAL">Normal</option>
<option value="PARCEIRO">Parceiro</option>
</select>
            <label for="placa">Placa *</label>
            <input type="text" name="placa" id="placa" required placeholder="ABC1D23 ou ABC1234">

            <label for="nome_cliente">Nome do cliente</label>
            <input type="text" name="nome_cliente" id="nome_cliente">

            <label for="modelo">Modelo</label>
            <input type="text" name="modelo" id="modelo">

            <label for="cor">Cor</label>
            <input type="text" name="cor" id="cor">

            <label for="observacoes">Observações</label>
            <textarea name="observacoes" id="observacoes" rows="3"></textarea>

            <input type="submit" value="Registrar entrada">
        </form>
    </div>
</div>
</body>
</html>
